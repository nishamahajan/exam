package com.phoenix.demos;

public class UiThread implements Runnable {

	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		process1();
		process2();

	}

	public synchronized void process1()
	{
		//Accept data using scanner
		String data;
		
		synchronized (data) {
			data="Value 1";
		}
		
		System.out.println("Process 1");
	}
	public void process2()
	{
		System.out.println("Process 2");
	}


}
