package com.phoenix.demos;

public class ThreadExample extends Thread{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Thread t1=new ThreadExample();
		Thread t2=new ThreadExample();
		t1.setName("ThreadA");
		t2.setName("ThreadB");
		t1.start();
		t2.start();
		//r();
		try {
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ThreadExample mainApp=new ThreadExample();
		mainApp.process5();

	}
	
	public void run()
	{
/*		System.out.println(Thread.currentThread().getName());
		System.out.println("Process executing");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("After Sleep");*/
		ThreadExample app=new ThreadExample();
		String threadName=Thread.currentThread().getName();
		if(threadName.equals("ThreadA"))
		{
			app.process1();
			app.process2();
		}
		else
		{
			app.process3();
			app.process4();
		}
	}

	public void process5()
	{
		System.out.println("Remaining processes");
	}
	public void process1()
	{
		System.out.println("Process 1");
	}
	public void process2()
	{
		System.out.println("Process 2");
	}
	public void process3()
	{
		System.out.println("Process 3");
	}
	public void process4()
	{
		System.out.println("Process 4");
	}
}
