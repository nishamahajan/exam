package com.phoenix.demos;

public class Restaurant {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Table t=new Table();
		Thread cust1=new Thread(new Customer("Chetan",t));
		Thread cust2=new Thread(new Customer("Mahesh",t));
		cust1.start();
		cust2.start();
	}
}
