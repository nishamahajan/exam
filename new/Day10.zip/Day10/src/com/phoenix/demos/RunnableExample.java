package com.phoenix.demos;

public class RunnableExample  {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Runnable ref=new UiThread();
		Thread ui=new Thread(ref);
		Thread ui1=new Thread(ref);
		Thread remote=new Thread(new RemoteThread());
		ui.start();
		remote.start();
	}

}
