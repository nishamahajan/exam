package com.phoenix.demos;

public class Customer implements Runnable {

	public String name;
	public Table currentTable;
	
	public Customer() {
		// TODO Auto-generated constructor stub
		currentTable.occupied=false;
	}
	
	public Customer(String name,Table t)
	{
		this.name=name;
		currentTable=t;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println(Thread.currentThread().getName());
		synchronized (currentTable) {
			if(currentTable.occupied==true)
			{
//				System.out.println(Thread.currentThread().getName()+ " " +currentTable.occupied);
				if(currentTable.custName.equals(this.name)==false)
				{
					try {
						System.out.println("customer " + this.name+ " is waiting");
						currentTable.wait();
						System.out.println("Customer " +this.name+ " is approaching the table");
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else
				{
					System.out.println("The customer "+currentTable.custName+" still has the table");
				}
			}
			else
			{
/*				synchronized (currentTable) 
				{*/
				currentTable.occupied=true;
				currentTable.custName=this.name;
				try {
					System.out.println("Customer " +this.name+ " has the table");
					Thread.sleep(5000);
					currentTable.custName=null;
					currentTable.occupied=false;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				currentTable.notify();
			}
		}
	}
}
