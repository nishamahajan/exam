package com.phoenix.demos;

public class Table {
	
	public String tableName;
	public boolean occupied;
	public String custName;
	
	public Table() {
		// TODO Auto-generated constructor stub
	}
	
	public Table(String name,boolean occ,String customer)
	{
		tableName=name;
		occupied=occ;
		custName=customer;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public boolean isOccupied() {
		return occupied;
	}

	public void setOccupied(boolean occupied) {
		this.occupied = occupied;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}
	

}
